/*
Use ONLY Arduino Nano(Old bootloader)
*/

#include <FastLED.h>
#include <Rcul.h>
#include <TinyPinChange.h>
#include <SoftRcPulseIn.h>
#include <TinyCppmReader.h>
#include <SoftSBusRx.h>
#include <EEPROM.h>

#include <RcRxSerial.h>
#include "Xany.h"

#define VERSION 1.8

/* Hystory
v1.0 Original version
v1.1 Add Towing and back position RGB leds
v1.2 Add Radar on pin 13
v1.3 Add chaserEffectMode on button
v1.4 Add SoftSBusRx input
v1.5 Change names leds fonctions and variables (5v to 3v and yellow)
v1.6 Add Failsafe / console start only after return
v1.7 Adds non-blocking code to the console in caterpillar and Christmas. 
v1.8 solve buttons issues
*/

SoftRcPulseIn PwmRcRBGLed;
TinyCppmReader TinyCppmReader;
uint8_t INPUT_RC_PIN   =   11;

bool consoleMode = false;
uint8_t  DebugNibbleByNibble = false;
bool DebugModeXany = false;
bool inAlert = false;
bool alarmLaunched = false;
bool ChechAlarmIsOn = true;
uint8_t XanyQuality = false;

uint16_t RculMsg = 0;

#define PRINT_BUF_SIZE      100
static char PrintBuf[PRINT_BUF_SIZE + 1];
#define PRINTF(fmt, ...)    do{if(Serial){snprintf_P(PrintBuf, PRINT_BUF_SIZE, PSTR(fmt) ,##__VA_ARGS__);Serial.print(PrintBuf);}}while(0)
#define PRINT_P(FlashStr)   do{if(Serial){Serial.print(FlashStr);}}while(0)

CRGB leds_Synchro[3];
uint32_t SYNCHRO_COLOR = CRGB::Red;
uint8_t  setBrightness = 50;

#define LED_RGB_NUMBER      10//si ajout feux arrière en remplacement de pin 6

#define MAST_LED4           9//haut du mât
#define MAST_LED3           8
#define MAST_LED2           7
#define MAST_LED1           6
#define MAST_LED0           5//bas du mât
#define CABINE              4
#define INTERIOR2           3
#define INTERIOR1           2
#define BACK2               1//Orange jaune en mode remorqueur
#define BACK1               0//blanc

/* Mast & Intérior definitions */
#define LED_RGB_PIN         12
CRGB leds_RGB_Mast_Interior[LED_RGB_NUMBER];

uint32_t MAST_LED4_COLOR = CRGB::White;
uint32_t MAST_LED3_COLOR = CRGB::Red;
uint32_t MAST_LED2_COLOR = CRGB::OrangeRed;
uint32_t MAST_LED1_COLOR = CRGB::Cyan;
uint32_t MAST_LED0_COLOR = CRGB::Purple;


uint32_t BACK_LED1_COLOR = CRGB::OrangeRed;
uint32_t BACK_LED0_COLOR = CRGB::Blue;

bool MastLed4 = false;
bool MastLed3 = false;
bool MastLed2 = false;
bool MastLed1 = false;
bool MastLed0 = false;

bool MastLed = false;
bool CabineLed = false;
bool InteriorLed = false;
bool ExteriorYellowLed = false;
bool ExteriorWhiteLed3v = false;

bool RedGreenPosionLed = false;
bool BackPositionLed = false;
bool TowingBackLed = false;

bool RadarOnOff = false;

// Délais et timing
unsigned long lastChange = 0;
int currentEffect = 0;
const int numEffects = 3;
const unsigned long effectDuration = 5000; // 5 secondes par effet
bool ChristmasMode = false;
bool ChaserEffetMode = false;

uint8_t gHue = false;  // Teinte de base qui change à chaque "tick"

typedef struct{
  uint16_t  Id;
  uint8_t   Version;
  uint8_t   XanyCh;
  uint8_t   InputType;
  uint8_t   XanyFilter;
  uint8_t   XanyPayload;
  uint32_t  CabineColor;
  uint32_t  InteriorColor;
} NvParamSt_t;

NvParamSt_t Nv;

uint8_t Outputs_Pins[] = {10, //feux position rouge et vert
                          8, //feux externes
                          6, //feu blanc arrière
                          4  //libre
};

#define RADAR_PIN         9//need PWM feature (atmega328p ==> D3,D5,D9,D10 and D11 only)
uint8_t Radar_Speed    =  40;

enum {INPUT_MODE_PWM = 0, INPUT_MODE_CPPM, INPUT_MODE_SBUS, INPUT_MODE_IBUS, INPUT_MODE_SUMD, INPUT_MODE_JETI, INPUT_MODE_SRXL, INPUT_MODE_SRXL2, INPUT_MODE_CRSF, INPUT_MODE_NB};
const char * INPUT_MODE_STR[]   = {"PWM", "CPPM", "SBUS", "IBUS", "SUMD", "JETI", "SRXL", "SRXL2", "CRSF"};

#define AVERAGE_LEVEL         2  /* Choose here the average level among the above listed values (0 to 4) */
#define AVERAGE(ValueToAverage,LastReceivedValue,AverageLevelInPowerOf2)  ValueToAverage=(((ValueToAverage)*((1<<(AverageLevelInPowerOf2))-1)+(LastReceivedValue))/(1<<(AverageLevelInPowerOf2)))

uint16_t PwmRcRBGLedUs = false;

//-------------------ALERTE --------------------------
#define SIGNAL_TIMEOUT_MS  500
struct AlertStatus {
  bool signalLost        = false;
  bool alertRcul         = false;
  bool wasFailsafe       = false;
  bool failsafe          = false;
  unsigned long lastRxMs = false;
};

AlertStatus alert;

//--------------------TIMER--------------------------
#include <elapsedMillis.h>

struct Timers {
  elapsedMillis SignalLost;
  elapsedMillis setBrightness;
  elapsedMillis ledInfo;
  elapsedMillis ManageLed;
  elapsedMillis effectDuration;
  elapsedMillis alert;
  elapsedMillis debug;
};

Timers timers;

//--------------------GESTION LED--------------------------
bool ledState = false;

// Sélection du mode de conversion de la luminosité
#define BRIGHT_MODE_LINEAR       0
#define BRIGHT_MODE_QUADRATIC    1
#define BRIGHT_MODE_EXPO_INV     2

#define BRIGHT_MODE BRIGHT_MODE_EXPO_INV  // <-- choisis ici le mode

void setup() 
{
  Serial.begin(115200);

  // Timeout USB Serial (ne bloque pas sans USB)
  uint32_t t0 = millis();
  while (!Serial && (millis() - t0 < 1500)) {
    delay(1);
  }

  for (uint8_t i = 0; i < 4; i++)
    pinMode(Outputs_Pins[i], OUTPUT);

  for (uint8_t i = 0; i < 4; i++)
    digitalWrite(Outputs_Pins[i], HIGH);

  delay(1000);

  for (uint8_t i = 0; i < 4; i++)
    digitalWrite(Outputs_Pins[i], LOW);

  analogWrite(RADAR_PIN, 0);

  PRINT_P("Lights RGB Module ");
  PRINT_P("for LOYAL MEDIATOR ");
  PRINT_P(VERSION);
  PRINT_P("\r\n");
  PRINT_P("  oO Powered By Rc-");
  PRINT_P("Navy libraries Oo\r\n\r\n");

  EEPROM.get(0, Nv);
  if(Nv.Id != 0x99)
  {
    writeDefaultSettings();
  }
  else
  {
    setup_Xany();
    readSettings();
  }
  delay(500);

  switch(Nv.InputType)
  {
    case INPUT_MODE_PWM:
      PwmRcRBGLed.attach(INPUT_RC_PIN);
      break;
    case INPUT_MODE_CPPM:
      TinyCppmReader.attach(INPUT_RC_PIN); /* Attach CPPM output to INPUT_RC_PIN pin */
      break;
    case INPUT_MODE_SBUS:
      SoftSBusRx.begin(INPUT_RC_PIN);/* Attach SBUS output (Without TTL inverter) to INPUT_RC_PIN pin */
      break;
  }

  
  FastLED.addLeds<WS2812B, 2,                 GRB>(leds_Synchro, 3);
  FastLED.addLeds<WS2812B, LED_RGB_PIN, GRB>(leds_RGB_Mast_Interior, LED_RGB_NUMBER);
  FastLED.clear();
  FastLED.setBrightness(200);//0 to 255
  chaserEffectStartup(80);
  FastLED.setBrightness(50);//0 to 255

  MastLed4 = false;
  MastLed3 = false;
  MastLed2 = false;
  MastLed1 = false;
  MastLed0 = false;
  CabineLed = false;
  InteriorLed = false;
  RedGreenPosionLed = false;
  BackPositionLed = false;
  TowingBackLed = false;
  ExteriorYellowLed = false;
  ExteriorWhiteLed3v = false;
  ChristmasMode = false;
  ChaserEffetMode = false;
  RadarOnOff = false;

  leds_Synchro[1] = CRGB::Black;
  leds_Synchro[2] = CRGB::Black;
  FastLED.show();

  PRINTF("Ws2812b : Ready\r\n\r\n");
  PRINTF("Use T command for unlock serial commands !\r\n");
}

void loop() 
{
  processUsbConsole();

  switch (Nv.InputType)
  {
    case INPUT_MODE_PWM:
    if (PwmRcRBGLed.available()) {
      AVERAGE(PwmRcRBGLedUs, PwmRcRBGLed.width_us(), AVERAGE_LEVEL);
      alert.lastRxMs = millis();
      alert.signalLost = false;
    }
    if (!PwmRcRBGLed.available() && (millis() - alert.lastRxMs > SIGNAL_TIMEOUT_MS)) {
      alert.signalLost = true;
    }
    break;
  
  case INPUT_MODE_CPPM:
    if (TinyCppmReader::detectedChannelNb() <= 16)
    {
      PwmRcRBGLedUs = TinyCppmReader::width_us(Nv.XanyCh);
      alert.lastRxMs = millis();
      alert.signalLost = false;
    } else if (millis() - alert.lastRxMs > SIGNAL_TIMEOUT_MS) {
      alert.signalLost = true;
      ChechAlarmIsOn = true;
    }
    break;
  case INPUT_MODE_SBUS:
    if(SoftSBusRx.isSynchro())
    {
      PwmRcRBGLedUs = SoftSBusRx.width_us(Nv.XanyCh);
      alert.lastRxMs = millis();
      alert.signalLost = false;
    } else if (millis() - alert.lastRxMs > SIGNAL_TIMEOUT_MS) {
      alert.signalLost = true;
      ChechAlarmIsOn = true;
    }
    break;
  }

  loop_Xany();

  if(timers.setBrightness > 1000)
  {
    timers.setBrightness = false;
    uint8_t bright = constrain(setBrightness, 5, 255);
    FastLED.setBrightness(bright);
    FastLED.show();
  }

  if (timers.SignalLost > 500)
  {
    timers.SignalLost = 0;
    SignalLost();
  }

  if(timers.ManageLed > 1000)
  {
    timers.ManageLed = 0;
    // Ne pas laisser ManageRGBLeds reprendre la main pendant le chenillard
    if (!ChaserEffetMode && !ChristmasMode) {
      ManageRGBLeds();
    }
  }

  if(ChristmasMode)
  {
    Christmas();
  }
  if(ChaserEffetMode)
  {
    chaserEffect(300);
  }

  RadarOnOff ? analogWrite(RADAR_PIN, Radar_Speed) : analogWrite(RADAR_PIN, 0);//Radar 9v

}

float applyBrightnessCurve(uint8_t light0to100) {
  const float exponent = 2.5f;
  float norm = constrain(light0to100, 0, 254);

#if BRIGHT_MODE == BRIGHT_MODE_LINEAR
  return norm;

#elif BRIGHT_MODE == BRIGHT_MODE_QUADRATIC
  return norm * norm;

#elif BRIGHT_MODE == BRIGHT_MODE_EXPO_INV
  return powf(norm, exponent);

#else
  return norm;
#endif
}

void SignalLost() {
  if ((alert.signalLost || alert.alertRcul /*|| alert.failsafe*/) /*&& ChechAlarmIsOn == true*/) {
    setBrightness = 200;
    blinkLED();
    
    if (!inAlert) {
      inAlert = true;
      alarmLaunched = false;
      timers.alert = 0;
    }

    if (!alarmLaunched && timers.alert >= 2000) {
      alarmLaunched = true;
    }
  } else {
    leds_Synchro[0] = CRGB::Black;
    FastLED.show();
    inAlert = false;
    alarmLaunched = false;
    timers.alert = 0;
  }

  if (alert.alertRcul) {
    RculMsg = 0;
  }
}

void blinkLED()
{
  if (timers.ledInfo > 1000)
  {
    timers.ledInfo = 0;

    ledState = !ledState;
    leds_RGB_Mast_Interior[9] = ledState ? CRGB::Red : CRGB::Black;

    FastLED.show();
  }
}

void chaserEffectStartup(uint16_t d)
{
  for (uint8_t n = 0; n < 3; n++) {
    for (int i = 0; i < LED_RGB_NUMBER; i++) {
      fill_solid(leds_RGB_Mast_Interior, LED_RGB_NUMBER, CRGB::Black);
      leds_RGB_Mast_Interior[i] = CHSV(gHue, 255, 255);
      FastLED.show();
      delay(d);
      gHue += 20;
    }

    for (int i = LED_RGB_NUMBER - 1; i >= 0; i--) {
      fill_solid(leds_RGB_Mast_Interior, LED_RGB_NUMBER, CRGB::Black);
      leds_RGB_Mast_Interior[i] = CHSV(gHue, 255, 255);
      FastLED.show();
      delay(d);
      gHue += 20;
    }
  }

  fill_solid(leds_RGB_Mast_Interior, LED_RGB_NUMBER, CRGB::Black);
  FastLED.show();
}

void chaserEffect(uint16_t d)//chennillard NON BLOQUANT
{
  static uint32_t lastStep = 0;
  static int8_t pos = 0;
  static int8_t dir = 1;

  if (!ChaserEffetMode) return;

  // Ne pas monopoliser le CPU
  if ((uint32_t)(millis() - lastStep) < d) return;
  lastStep = millis();

  fill_solid(leds_RGB_Mast_Interior, LED_RGB_NUMBER, CRGB::Black);

  leds_RGB_Mast_Interior[pos] = CHSV(gHue, 255, 255);

  FastLED.show();

  gHue += 20;

  pos += dir;

  if (pos >= LED_RGB_NUMBER - 1) {
    pos = LED_RGB_NUMBER - 1;
    dir = -1;
  }
  else if (pos <= 0) {
    pos = 0;
    dir = 1;
  }
}

void Christmas()
{
  static uint32_t lastChristmasStep = 0;

  // rythme de l'effet, remplace FastLED.delay(300)
  if (millis() - lastChristmasStep < 300) return;
  lastChristmasStep = millis();

  if (millis() - lastChange > effectDuration) {
    currentEffect = (currentEffect + 1) % numEffects;
    lastChange = millis();
  }

  switch (currentEffect) {
    case 0:
      effetRougeVert();
      break;
    case 1:
      effetScintillement();
      break;
    case 2:
      effetBalayage();
      break;
  }

  FastLED.show();
}

// 🎅 Rouge et vert alterné
void effetRougeVert() {
  for (int i = 0; i < LED_RGB_NUMBER; i++) {
    leds_RGB_Mast_Interior[i] = (i % 2 == 0) ? CRGB::Red : CRGB::Green;
  }
}

// ❄️ Scintillement blanc/bleu
void effetScintillement() {
  for (int i = 0; i < LED_RGB_NUMBER; i++) {
    if (random(0, 10) > 7) {
      leds_RGB_Mast_Interior[i] = (random(0, 2) == 0) ? CRGB::White : CRGB::Blue;
    } else {
      leds_RGB_Mast_Interior[i].fadeToBlackBy(100);
    }
  }
}

// 🌟 Balayage rouge
void effetBalayage() {
  static int position = 0;
  fill_solid(leds_RGB_Mast_Interior, LED_RGB_NUMBER, CRGB::Black);
  leds_RGB_Mast_Interior[position] = CRGB::Red;
  position = (position + 1) % LED_RGB_NUMBER;
}

void DefineInteriorLeds()
{
  InteriorLed = !InteriorLed;
  PRINTF("Intérieur %s\r\n",InteriorLed?"ON":"OFF");
}

void DefineExteriorYellowLeds()
{
  ExteriorYellowLed = !ExteriorYellowLed;
  PRINTF("Extérieur Leds Jaunes %s\r\n",ExteriorYellowLed?"ON":"OFF");
}

void DefineExteriorWhiteLeds3v()
{
  ExteriorWhiteLed3v = !ExteriorWhiteLed3v;
  PRINTF("Extérieur Leds Blanches %s\r\n",ExteriorWhiteLed3v?"ON":"OFF");
}

//Le LOYAL MEDIATOR (IMO: 7636420) est un Offshore Supply Ship Sa longueur hors tout (LOA) est de 24.33 meters mètres et sa largeur est de 6.4 mètres.
void DefineMastLightByBoatState(uint8_t state)
{
  switch(state)
  {
    case 0:// feux de positions
      RedGreenPosionLed = true;
      BackPositionLed = true;
      TowingBackLed = false;

      BACK_LED0_COLOR = CRGB::White;

      MAST_LED3_COLOR = CRGB::White;
      MastLed4 = false;
      MastLed3 = true;
      MastLed2 = false;
      MastLed1 = false;
      MastLed0 = false;

      Serial.println("Position ON");
      break;

    case 1:// Interior & Exteriors
      InteriorLed = true;
      ExteriorYellowLed = true;
      ExteriorWhiteLed3v = true;

      Serial.println("Interior & Exteriors ON");
      break;

    case 2:// plongeurs
      RedGreenPosionLed = false;
      BackPositionLed = false;
      TowingBackLed = false;

      MAST_LED3_COLOR = CRGB::Red;
      MAST_LED2_COLOR = CRGB::White;
      MAST_LED1_COLOR = CRGB::Red;

      MastLed4 = false;
      MastLed3 = true;
      MastLed2 = true;
      MastLed1 = true;
      MastLed0 = false;

      Serial.println("Plongeurs ON");
      break;

    case 3://4 capacité restreinte
      RedGreenPosionLed = false;
      BackPositionLed = true;
      TowingBackLed = false;
      BACK_LED0_COLOR = CRGB::White;

      MAST_LED4_COLOR = CRGB::Red;
      MAST_LED3_COLOR = CRGB::White;
      MAST_LED2_COLOR = CRGB::Red;

      MastLed4 = true;
      MastLed3 = true;
      MastLed2 = true;
      MastLed1 = false;
      MastLed0 = false;

      Serial.println("Restreint ON");
      break;

    case 4:// pas maître de la manœuvre
      RedGreenPosionLed = true;
      BackPositionLed = false;
      TowingBackLed = false;

      MAST_LED3_COLOR = CRGB::Red;
      MAST_LED1_COLOR = CRGB::Red;

      MastLed4 = false;
      MastLed3 = true;
      MastLed2 = false;
      MastLed1 = true;
      MastLed0 = false;

      Serial.println("Manœuvre limitée ON");
      break;

    case 5:// échoué
      RedGreenPosionLed = false;
      BackPositionLed = false;
      TowingBackLed = false;

      MAST_LED3_COLOR = CRGB::Red;
      MAST_LED2_COLOR = CRGB::Red;
      MAST_LED1_COLOR = CRGB::Red;

      MastLed4 = false;
      MastLed3 = true;
      MastLed2 = true;
      MastLed1 = true;
      MastLed0 = false;

      Serial.println("Echoué ON");
      break;

    case 6:// mouillage
      RedGreenPosionLed = false;
      BackPositionLed = false;
      TowingBackLed = false;

      MAST_LED4_COLOR = CRGB::White;

      MastLed4 = true;
      MastLed3 = false;
      MastLed2 = false;
      MastLed1 = false;
      MastLed0 = false;

      Serial.println("Mouillage ON");
      break;

    case 7:// remorquage
      RedGreenPosionLed = false;
      BackPositionLed = true;
      TowingBackLed = true;

      BACK_LED1_COLOR = CRGB::OrangeRed;
      BACK_LED0_COLOR = CRGB::White;

      MAST_LED1_COLOR = CRGB::White;
      MAST_LED0_COLOR = CRGB::White;

      MastLed4 = false;
      MastLed3 = false;
      MastLed2 = false;
      MastLed1 = true;
      MastLed0 = true;

      Serial.println("Remorquage ON");
      break;

    case 8:// All OFF ou Dangerous Goods
      if (Nv.XanyPayload == XANY_PAYLOAD_SW16_PLUS_PROP)
      {
        InteriorLed = true;
        ExteriorYellowLed = true;
        ExteriorWhiteLed3v = true;

        RedGreenPosionLed = true;
        BackPositionLed = true;
        TowingBackLed = false;

        MastLed4 = true;
        MastLed3 = true;
        MastLed2 = true;
        MastLed1 = false;
        MastLed0 = false;

        BACK_LED0_COLOR = CRGB::White;

        MAST_LED4_COLOR = CRGB::Blue;
        MAST_LED3_COLOR = CRGB::Blue;
        MAST_LED2_COLOR = CRGB::Blue;
        MAST_LED1_COLOR = CRGB::White;

        Serial.println("Dangerous Goods");
      }
      else
      {
        // ALL OFF → sera géré par reset global
        Serial.println("All OFF");
      }
      break;

    case 9:// Christmas
      ChristmasMode = true;
      Serial.println("Christmas ON");
      break;

    case 10:// Chaser
      ChaserEffetMode = true;
      ChristmasMode = false;
      Serial.println("ChaserEffect ON");
      break;

    case 14:// Radar
      RadarOnOff = true;
      Serial.println("Radar ON");
      break;

    case 15:// All OFF
      // sera géré par reset global dans ApplyAllBoatStates()
      Serial.println("All OFF");
      break;
  }
}

void ManageRGBLeds()
{
  if (!alarmLaunched)
    MastLed4 ? leds_RGB_Mast_Interior[MAST_LED4] = MAST_LED4_COLOR : leds_RGB_Mast_Interior[MAST_LED4] = CRGB::Black;
  else
  {
    leds_RGB_Mast_Interior[MAST_LED4] = CRGB::Red;
    MastLed3 = false;MastLed2 = false;MastLed1 = false;MastLed0 = false;CabineLed = false;ExteriorYellowLed = false;ExteriorWhiteLed3v = false;InteriorLed = false;RedGreenPosionLed = false;BackPositionLed = false; TowingBackLed = false;
  }

  MastLed3 ? leds_RGB_Mast_Interior[MAST_LED3] = MAST_LED3_COLOR : leds_RGB_Mast_Interior[MAST_LED3] = CRGB::Black;
  MastLed2 ? leds_RGB_Mast_Interior[MAST_LED2] = MAST_LED2_COLOR : leds_RGB_Mast_Interior[MAST_LED2] = CRGB::Black;
  MastLed1 ? leds_RGB_Mast_Interior[MAST_LED1] = MAST_LED1_COLOR : leds_RGB_Mast_Interior[MAST_LED1] = CRGB::Black;
  MastLed0 ? leds_RGB_Mast_Interior[MAST_LED0] = MAST_LED0_COLOR : leds_RGB_Mast_Interior[MAST_LED0] = CRGB::Black;

  CabineLed ? leds_RGB_Mast_Interior[CABINE] = Nv.CabineColor : leds_RGB_Mast_Interior[CABINE] = CRGB::Black;

  InteriorLed ? leds_RGB_Mast_Interior[INTERIOR1] = Nv.InteriorColor : leds_RGB_Mast_Interior[INTERIOR1] = CRGB::Black;
  InteriorLed ? leds_RGB_Mast_Interior[INTERIOR2] = Nv.InteriorColor : leds_RGB_Mast_Interior[INTERIOR2] = CRGB::Black;

  BackPositionLed ? leds_RGB_Mast_Interior[BACK1] = BACK_LED0_COLOR : leds_RGB_Mast_Interior[BACK1] = CRGB::Black;
  TowingBackLed   ? leds_RGB_Mast_Interior[BACK2] = BACK_LED1_COLOR : leds_RGB_Mast_Interior[BACK2] = CRGB::Black;

  RedGreenPosionLed  ? digitalWrite(Outputs_Pins[0], HIGH) : digitalWrite(Outputs_Pins[0], LOW);//Red & Green position 9v
  ExteriorYellowLed ? digitalWrite(Outputs_Pins[1], HIGH) : digitalWrite(Outputs_Pins[1], LOW);//extérieurs + cheminée 9v
  ExteriorWhiteLed3v ? digitalWrite(Outputs_Pins[2], HIGH) : digitalWrite(Outputs_Pins[2], LOW);//leds blanches 3v

  FastLED.show();

}

// extern int __heap_start, *__brkval;
// int freeMemory() {
//   int v;
//   return (int) &v - (__brkval == 0 ? (int) &__heap_start : (int) __brkval);
// }