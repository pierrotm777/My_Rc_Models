#ifndef XANY_H
#define XANY_H

enum {XANY_PAYLOAD_SW8 = 0, XANY_PAYLOAD_SW16, XANY_PAYLOAD_SW8_PLUS_PROP, XANY_PAYLOAD_SW16_PLUS_PROP, XANY_PAYLOAD_NB};

/******************************/
/* Public Function Prototypes */
/******************************/
void        Xany_setup();//Used one time on setup
void        Xany_reassignScr(uint8_t NewScr);//RCUL1
const char *Xany_getPayloadName(uint8_t PayloadIdx);

#endif