#include "Xany.h"				 
/* 
  XANY is usable with All protocols, PWM, CPPM or RCBUSRX(SBUS,IBUS,SUMD,SRXL,JETIEX)
  SBUS or SRXL or SUMD or IBUS or JETI to read a receiver channel output 
*/


/* /!\ SHALL follow enum{} of Xany.h /!\ */
const char * XANY_PAYLOAD_STR[] = {"SW:8", "SW:16", "SW:8 + PROP", "SW:16 + PROP"};
													   

const char *Xany_getPayloadName(uint8_t PayloadIdx)
{
  if(PayloadIdx < XANY_PAYLOAD_NB)
  {
    return(XANY_PAYLOAD_STR[PayloadIdx]);
  }
  return((const char*)"");
}			

/* vvv User XANY configuration vvv */
#define RC_FILTER_LEVEL     0   /* Possible values: 0=No Filtering, 1 to 3=Filtering */
uint8_t DATA_RC_CHANNEL  =  0;              /* If Mode = CPPM or SBUS or SRXL or SUMD or IBUS or JETI, define here the channel to Read */
/* Define below the expected X-Any payload (as defined in OpenAVRc XAny OR BURC Encoder menu, otherwise the decoding will be wrong! */
uint8_t ANGLE        =      0;              /* 0: Not present, 1: Present  NOT USED FOR THIS PROJECT */
uint8_t PROP         =      0;              /* 0: Not present, 1: Present */
uint8_t SW           =      16;              /* 0, Not present, 4: 4xSW, 8: 8xSW or 16: 16xSW */

/* Message Length check */
#define IGNORE_NIBBLE_LEN   0               /* Set this to 1 for variable length message (Not recommanded) */
/* ^^^ User sketch configuration ^^^ */

#define EXPECTED_NIBBLE_LEN   ((ANGLE * 3) + (PROP * 2) + (SW / 4))


#include <RcRxSerial.h>

#define HTONS(x)                          __builtin_bswap16((uint16_t) (x))

#define TABLE_ITEM_NBR(Tbl)               (sizeof(Tbl) / sizeof(Tbl[0]))
enum {NIBBLE_0 = 0, NIBBLE_1, NIBBLE_2, NIBBLE_3, NIBBLE_4, NIBBLE_5, NIBBLE_6, NIBBLE_7, NIBBLE_8, NIBBLE_9, NIBBLE_A, NIBBLE_B, NIBBLE_C, NIBBLE_D, NIBBLE_E, NIBBLE_F, NIBBLE_R, NIBBLE_I, NIBBLE_NB};

#define NEUTRAL_WIDTH_US                  1500//ms.CENTER_CH
#define NIBBLE_WIDTH_US                   56
#define FULL_EXCURSION_US                 (NIBBLE_WIDTH_US * NIBBLE_NB)
#define PULSE_MIN_US                      (NEUTRAL_WIDTH_US - (FULL_EXCURSION_US / 2))
#define PULSE_WIDTH_US(NibbleIdx)         (PULSE_MIN_US + (NIBBLE_WIDTH_US / 2)+ ((NibbleIdx) * NIBBLE_WIDTH_US))
#define EXCURSION_HALF_US(NibbleIdx)      ((PULSE_WIDTH_US(NibbleIdx) - NEUTRAL_WIDTH_US) * 2)

#define X_ANY_MSG_LEN                     sizeof(X_OneAnyReadMsgSt_t)

const int16_t ExcursionHalf_us[] PROGMEM = {EXCURSION_HALF_US(NIBBLE_0), EXCURSION_HALF_US(NIBBLE_1), EXCURSION_HALF_US(NIBBLE_2), EXCURSION_HALF_US(NIBBLE_3),
                                            EXCURSION_HALF_US(NIBBLE_4), EXCURSION_HALF_US(NIBBLE_5), EXCURSION_HALF_US(NIBBLE_6), EXCURSION_HALF_US(NIBBLE_7),
                                            EXCURSION_HALF_US(NIBBLE_8), EXCURSION_HALF_US(NIBBLE_9), EXCURSION_HALF_US(NIBBLE_A), EXCURSION_HALF_US(NIBBLE_B),
                                            EXCURSION_HALF_US(NIBBLE_C), EXCURSION_HALF_US(NIBBLE_D), EXCURSION_HALF_US(NIBBLE_E), EXCURSION_HALF_US(NIBBLE_F),
                                            EXCURSION_HALF_US(NIBBLE_R), EXCURSION_HALF_US(NIBBLE_I)};

#define GET_EXC_HALF_US(NibbleIdx)        (int16_t)pgm_read_word(&ExcursionHalf_us[(NibbleIdx)])

#define INACTIVITY_MS       3000UL
#define RX_MSG_LEN_MAX      6

RcRxSerial   MyRcRxSerial(&PwmRcRBGLed, RC_FILTER_LEVEL, DATA_RC_CHANNEL);

typedef struct{
  uint8_t RxFrameCnt;
  uint8_t ErrorCnt;
}XanyStatSt_t;

static uint8_t RxMsg[RX_MSG_LEN_MAX];//dans XanyToSpy
static XanyStatSt_t   XanyStat = {0, 0};
void PrintBin(uint8_t *Buf, uint8_t BufSize, uint8_t RemainingNibble = 0);
void PrintByteBin(uint8_t Byte, uint8_t RemainingNibble = 0);
void ByteBinToPlaySoundNb(uint8_t Byte, uint8_t RemainingNibble/* = 0*/);

uint8_t qualityCount = 20;

uint16_t GetSwitch(uint8_t *RxMsg);

static bool toggleState[16] = {0};

void Xany_reassignScr(uint8_t NewScr)
{
  switch(NewScr)
  {
    case INPUT_MODE_PWM:   MyRcRxSerial.reassignRculSrc(&PwmRcRBGLed, RCUL_NO_CH, 0);break;
    case INPUT_MODE_CPPM:  MyRcRxSerial.reassignRculSrc(&TinyCppmReader, Nv.XanyCh, 0);break;
    case INPUT_MODE_SBUS:  MyRcRxSerial.reassignRculSrc(&SoftSBusRx, Nv.XanyCh, 0);break;
  }  
}

void setup_Xany()//Used one time on setup
{ 
  switch(Nv.XanyPayload)
  {
    case XANY_PAYLOAD_SW8:            SW=8;  PROP=0; ANGLE=0; break;
    case XANY_PAYLOAD_SW16:           SW=16; PROP=0; ANGLE=0; break;
    case XANY_PAYLOAD_SW8_PLUS_PROP:  SW=8;  PROP=1; ANGLE=0; break;
    case XANY_PAYLOAD_SW16_PLUS_PROP: SW=16; PROP=1; ANGLE=0; break;
  }  
  MyRcRxSerial.setFilter(Nv.XanyFilter);
  Xany_reassignScr(Nv.InputType);

  if (Nv.InputType != 0)
  {
    if (Nv.XanyFilter !=0)
      PRINTF("%s [ Xany ] use Channel %d(RCUL) | Filter:%d | %s\r\n",  INPUT_MODE_STR[Nv.InputType], Nv.XanyCh, Nv.XanyFilter, Xany_getPayloadName(Nv.XanyPayload));
    else
      PRINTF("%s [ Xany ] use Channel %d(RCUL) | No Filter | %s\r\n",  INPUT_MODE_STR[Nv.InputType], Nv.XanyCh, Xany_getPayloadName(Nv.XanyPayload));   
  }
  else
  {
    if (Nv.XanyFilter !=0)
      PRINTF("%s [ Xany ] use Filter:%d | %s\r\n", INPUT_MODE_STR[Nv.InputType], Nv.XanyFilter, Xany_getPayloadName(Nv.XanyPayload));
    else
      PRINTF("%s [ Xany ] No Filter | %s\r\n", INPUT_MODE_STR[Nv.InputType], Xany_getPayloadName(Nv.XanyPayload));
  }
    
}

static bool IsMastMode(uint8_t SwIdx)
{
  // Les modes de mât utilisent les mêmes leds.
  // Ils doivent donc être exclusifs : un seul mode de mât actif à la fois.
  return (SwIdx == 0 ||
          SwIdx == 2 ||
          SwIdx == 3 ||
          SwIdx == 4 ||
          SwIdx == 5 ||
          SwIdx == 6 ||
          SwIdx == 7 ||
          SwIdx == 8);
}

static void ClearOtherMastModes(uint8_t KeepIdx)
{
  for (uint8_t i = 0; i < SW; i++)
  {
    if (i != KeepIdx && IsMastMode(i))
    {
      toggleState[i] = false;
    }
  }
}

static void ClearAllToggleStates()
{
  for (uint8_t i = 0; i < 16; i++)
  {
    toggleState[i] = false;
  }
}

void ApplyAllBoatStates()
{
  // reset de base
  RedGreenPosionLed = false;
  BackPositionLed = false;
  TowingBackLed = false;

  MastLed4 = false;
  MastLed3 = false;
  MastLed2 = false;
  MastLed1 = false;
  MastLed0 = false;

  InteriorLed = false;
  ExteriorYellowLed = false;
  ExteriorWhiteLed3v = false;

  RadarOnOff = false;
  ChristmasMode = false;
  ChaserEffetMode = false;

  // on réapplique uniquement les boutons encore ON
  for (uint8_t i = 0; i < SW; i++)
  {
    if (toggleState[i])
    {
      DefineMastLightByBoatState(i);
    }
  }
}

void loop_Xany()
{
  uint16_t        lastWidth_us;
  static uint32_t StartMs;
  static uint32_t LastActivityStartMs = millis(), LastMsgStartMs = millis();
  static uint16_t PrevSw = 0;
  static uint16_t CurrentSw = 0;

  // ── Mode Debug nibble par nibble ───────────────────────────────────────
  if (DebugNibbleByNibble)
  {
    MyRcRxSerial.available();
    if (MyRcRxSerial.nibbleAvailable())
    {
      lastWidth_us = MyRcRxSerial.lastWidth_us();
      Serial.print(lastWidth_us);
      Serial.print(F(" -> "));
      Serial.write(NibbleIdx2Nibble(PulseWithToNibbleIdx(lastWidth_us - NEUTRAL_WIDTH_US)));
      Serial.print(" T="); Serial.print(millis() - StartMs); Serial.println();
      StartMs = millis();
    }
    return;
  }

  // ── Lecture filtrée de la trame X-Any ─────────────────────────────────
  static uint8_t  tmp[RX_MSG_LEN_MAX];
  static unsigned long lastRx = 0;
  const  unsigned long timeout = INACTIVITY_MS;
  uint8_t RxMsgAttr, RxByteLen, RxNibbleLen;

  if ((RxMsgAttr = MyRcRxSerial.msgAvailable((char*)tmp, RX_MSG_LEN_MAX)))
  {
    lastRx = millis();

    // longueur octets et nibbles reçus
    RxByteLen   = RxMsgAttr & ~RC_RX_SERIAL_PENDING_NIBBLE_INDICATOR;
    RxNibbleLen = RxByteLen * 2
                 + ((RxMsgAttr & RC_RX_SERIAL_PENDING_NIBBLE_INDICATOR) ? 1 : 0);

    // n’accepte que trames paires, longueur exacte + checksum OK
    if ((RxMsgAttr & RC_RX_SERIAL_PENDING_NIBBLE_INDICATOR) == 0
        && RxNibbleLen == (EXPECTED_NIBBLE_LEN + 2)
        && RcRxSerial::msgChecksumIsValid((char*)tmp, RxMsgAttr))
    {
      // on garde la trame
      memcpy(RxMsg, tmp, RxByteLen);
      alert.alertRcul = false; // Réinitialiser l'alerte si un message valide est reçu
      XanyStat.RxFrameCnt++;
      LastActivityStartMs = millis();

      // ── Bloc de debug détaillé ────────────────────────────────────────
      if (DebugModeXany)
      {
        Serial.println();
        Serial.print("X-Any Msg[TotNbl="); Serial.print(RxNibbleLen); Serial.print("]=");
        PrintBin((uint8_t *)&RxMsg, (RxNibbleLen / 2) - 1, RxNibbleLen & 1);
        Serial.print(" T="); Serial.println(millis() - LastMsgStartMs);
      }
        // Angle
        // if (ANGLE == 1)
        // {
        //   float AngleFloat = (360.0 * GetAngle(RxMsg)) / 4095.0;
        //   if (DebugModeXany)
        //   {
        //     Serial.print("Angle="); Serial.print(GetAngle(RxMsg));
        //     Serial.print(" ("); Serial.print(AngleFloat, 1); Serial.println("°)");
        //   }
        // }

        //PROP LED'S RGB Brightness
        if (PROP == 1)
        {
          setBrightness = GetProp(RxMsg);
          if (DebugModeXany)
            PRINTF("Prop= %d ", setBrightness);
        }

        // Switch bits
        if (SW > 0)
        {
          uint16_t Word = GetSwitch(RxMsg);
          if (DebugModeXany)
          {
            Serial.print("Switch["); Serial.print(SW); Serial.print("..1]=");
          }

          if (SW == 16)
            Word = HTONS(Word);
          if (SW == 4)
            Word <<= 4;
          uint8_t *Ptr = (uint8_t *)&Word;
          if (DebugModeXany)
          {
            PrintBin(Ptr, SW / 8, (SW == 4));
            Serial.println();
          }

        }

        LastMsgStartMs = millis();

        // qualité X-Any
        if ((XanyStat.RxFrameCnt >= qualityCount) && DebugModeXany)
        {
          Serial.print(" Xany quality = ");
          Serial.print((XanyStat.RxFrameCnt - XanyStat.ErrorCnt) * 100 / qualityCount);
          Serial.println(" %");
          XanyStat.RxFrameCnt = XanyStat.ErrorCnt = 0;
        }
      
      // ────────────────────────────────────────────────────────────────────
    }
    else
    {
      // idle nibble ou trame défectueuse ?
      XanyStat.ErrorCnt++;
      if (DebugModeXany)
      {
        Serial.print("X-Any Length/Checksum error! ");
        Serial.print("ExpNbl="); Serial.print(EXPECTED_NIBBLE_LEN + 2);
        Serial.print(" RxNbl="); Serial.println(RxNibbleLen);
      }
    }
  }//end MyRcRxSerial.msgAvailable

  // ── Failsafe si plus de trame valide depuis timeout ───────────────────
  if (millis() - LastActivityStartMs > INACTIVITY_MS)
  {
    LastActivityStartMs  = millis();
    alert.alertRcul = true;
    alert.signalLost = true;
    if (DebugModeXany) Serial.println("X-Any Failsafe! -> Outputs = 0");
    memset(RxMsg, 0, sizeof(RxMsg));
  }


  // ── Extraction des SW (8 or 16) switches & toggle ────────────────────────────────
  CurrentSw = GetSwitch(RxMsg);

  uint16_t NewPressed = CurrentSw & ~PrevSw;   // seulement les nouveaux appuis

  if (NewPressed)
  {
    for (uint8_t SwIdx = 0; SwIdx < SW; SwIdx++)
    {
      if (bitRead(NewPressed, SwIdx))
      {
        // Bouton ALL OFF : bouton 16 en SW16.
        // En SW8, on garde aussi le dernier bouton comme arrêt général si besoin.
        if ((Nv.XanyPayload == XANY_PAYLOAD_SW16_PLUS_PROP && SwIdx == 15) ||
            (Nv.XanyPayload == XANY_PAYLOAD_SW8_PLUS_PROP  && SwIdx == 7))
        {
          ClearAllToggleStates();
          ApplyAllBoatStates();

          fill_solid(leds_RGB_Mast_Interior, LED_RGB_NUMBER, CRGB::Black);
          fill_solid(leds_Synchro, 3, CRGB::Black);
          FastLED.show();

          Serial.println(F("All OFF"));
        }
        else if (IsMastMode(SwIdx))
        {
          // Les modes de mât sont exclusifs.
          // Si un autre mode de mât était actif, il est remplacé par celui-ci.
          if (toggleState[SwIdx])
          {
            // Même bouton mât -> OFF
            toggleState[SwIdx] = false;
          }
          else
          {
            // Nouveau bouton mât -> seul ce mode reste actif
            ClearOtherMastModes(SwIdx);
            toggleState[SwIdx] = true;
          }

          ApplyAllBoatStates();
        }
        else
        {
          // Boutons indépendants : intérieur/extérieurs, Noël, chenillard, radar...
          toggleState[SwIdx] = !toggleState[SwIdx];
          ApplyAllBoatStates();
        }

        break;
      }
    }
  }

  PrevSw = CurrentSw;
}//loop_Xany

/* Note used for this project */
// uint16_t GetAngle(uint8_t *RxMsg)
// {
//   uint16_t AngleValue;
//   AngleValue = (RxMsg[0] << 4) + (RxMsg[1] >> 4);
//   return(AngleValue);
// }

uint16_t GetProp(uint8_t *RxMsg)
{
  uint8_t PropValue;
  if (ANGLE == 1)
  {
    /* PropValue is after the Angle field */
    PropValue  = (RxMsg[1] & 0x0F) << 4;
    PropValue |= (RxMsg[2] & 0xF0) >> 4;
  }
  else
  {
    /* PropValue is the first field */
    PropValue = RxMsg[0];
  }  
  return(PropValue);
}

uint16_t GetSwitch(uint8_t *RxMsg)
{
  uint16_t Sw = 0;

  if (SW < 16)
  {
    /* Sw.4 and Sw.8 */
    if (ANGLE == 1)
    {
      if (SW == 4)
      {
        /* SW = 4 */
        Sw |= RxMsg[1 + !!PROP] & 0x0F;
      }
      else
      {
        /* SW = 8 */
        Sw |= (RxMsg[1 + !!PROP] & 0x0F) << 4;
        Sw |= (RxMsg[2 + !!PROP] & 0xF0) >> 4;
      }
    }
    else
    {
      if (SW == 4)
      {
        /* SW = 4 */
        Sw |= (RxMsg[0 + !!PROP] & 0xF0) >> 4;
      }
      else
      {
        /* SW = 8 */
        Sw |= RxMsg[0 + !!PROP];
      }
    }
  }
  else
  {
    /* Sw.16 */
    if (ANGLE == 1)
    {
      Sw |= (RxMsg[1 + !!PROP] & 0x0F) << 12;
      Sw |= (RxMsg[2 + !!PROP] << 4);
      Sw |= (RxMsg[3 + !!PROP] & 0xF0) >> 4;
    }
    else
    {
      Sw |= RxMsg[0 + !!PROP] << 8;
      Sw |= RxMsg[1 + !!PROP];
    }
  }
    return(Sw);
}

int8_t PulseWithToNibbleIdx(int16_t ExcursionWidth)
{
  int8_t  Ret = -1;
  uint8_t Idx;

  for(Idx = 0; Idx < TABLE_ITEM_NBR(ExcursionHalf_us); Idx++)
  {
    if( (ExcursionWidth >= ((GET_EXC_HALF_US(Idx)/2) - 28)) && (ExcursionWidth <= ((GET_EXC_HALF_US(Idx)/2) + 28)) )
    {
      Ret = Idx;
      break;
    }
  }
  return(Ret);
}

uint8_t NibbleIdx2Nibble(uint8_t NibbleIdx)
{
  uint8_t Nibble;
  
  switch(NibbleIdx)
  {      
    case 16:
    Nibble = 'R';
    break;
    
    case 17:
    Nibble = 'I';
    break;
    
    default:
    if(NibbleIdx < 10)
    {
      Nibble = '0' + NibbleIdx;
    }
    else
    {
      Nibble = 'A' - 10 + NibbleIdx;
    }      
    break;
  }
  return(Nibble);
}

void PrintBin(uint8_t *Buf, uint8_t BufSize, uint8_t RemainingNibble/* = 0*/)
{
  uint8_t ByteIdx;
  for(ByteIdx =0; ByteIdx < BufSize; ByteIdx++)
  {
    //if(ByteIdx) Serial.print("-");
    PrintByteBin(Buf[ByteIdx]);
  }
  if(RemainingNibble)
  {
    //if(BufSize) Serial.print(".");
    PrintByteBin(Buf[ByteIdx], RemainingNibble);
  }
}

void PrintByteBin(uint8_t Byte, uint8_t RemainingNibble/* = 0*/)
{
  for(uint8_t Idx = 0; Idx < 8; Idx++)
  {
    if(DebugModeXany)
    {
	    Serial.print(bitRead(Byte, 7 - Idx));
    }
    if(Idx == 3)
    {
      if(RemainingNibble) break;
      //Serial.print(".");
    } 
  }
}

