void usbHelp(void)
{
  Serial.println(F("\r\nH Help"));
  Serial.println(F("SW set Default settings"));
  Serial.println(F("S? Read Settings"));
  Serial.println(F("SI A Define Protocol A => 0=PWM, 1=CPPM, 2=SBUS_INV"));//, 3=IBUS, 4=SUMD, 5=JETI, 6=SRXL, 7=SRXL2, 8=CRSF"));
  Serial.println(F("SX A B A=Channel, B=PayLoad Xany Settings"));
  Serial.println(F("T set ON/OFF Alarm's Check"));
  Serial.println(F("A set ON/OFF All Leds"));
  Serial.print  (F("M set ON/OFF All Mast's"));Serial.println(F(" Leds (or M X Led by Led)"));
  Serial.print  (F("I X Y set X=0 to 3 Cabin's color / Y=1 On/Off Interior"));
  Serial.println(F("L X set Mast Leds by boat's state"));
  Serial.println(F("B X set brightness for all leds"));
  Serial.println(F("DN Xany Debug Nibble by Nibble ON/OFF"));
  Serial.println(F("DX Xany Debug Bits/Quality ON/OFF"));
  Serial.println(F("Q quit console mode"));
  Serial.println(F("\r\n"));
}

void AlarmCheckOnOff()
{
  ChechAlarmIsOn = !ChechAlarmIsOn;
  if (ChechAlarmIsOn == false)
  {
    MastLed4 = false;
    MastLed3 = false;
    MastLed2 = false;
    MastLed1 = false;
    MastLed0 = false;
    CabineLed = false;
    InteriorLed = false;
    ExteriorYellowLed = false;
    RedGreenPosionLed = false;
    BackPositionLed = false;
    TowingBackLed = false;

    RadarOnOff = false;

    ExteriorWhiteLed3v = false;
  }
  PRINTF("Alarm's check is %s !\r\n\r\n", ChechAlarmIsOn? "ON":"OFF");
}


void AllLeds()
{
  MastLed     = !MastLed;
  CabineLed   = !CabineLed;
  InteriorLed = !InteriorLed;
  RedGreenPosionLed = !RedGreenPosionLed;
  BackPositionLed = !BackPositionLed;
  TowingBackLed = !TowingBackLed;

  RadarOnOff = !RadarOnOff;

  ExteriorWhiteLed3v = !ExteriorWhiteLed3v;
  if (MastLed && CabineLed && InteriorLed && RedGreenPosionLed && BackPositionLed && TowingBackLed && ExteriorWhiteLed3v && RadarOnOff)
  {
    MastLed0 = true;
    MastLed1 = true;
    MastLed2 = true;
    MastLed3 = true;
    MastLed4 = true;
    CabineLed = true;
    InteriorLed = true;
    ExteriorYellowLed = true;
    RedGreenPosionLed = true;
    BackPositionLed = true;
    TowingBackLed = true;

    RadarOnOff = true;

    ExteriorWhiteLed3v = true;
    PRINT_P("All is ON !");
  }
  else if (!MastLed && !CabineLed && !InteriorLed && !RedGreenPosionLed && !BackPositionLed && !TowingBackLed && !ExteriorWhiteLed3v && !RadarOnOff)
  {
    MastLed4 = false;
    MastLed3 = false;
    MastLed2 = false;
    MastLed1 = false;
    MastLed0 = false;
    CabineLed = false;
    InteriorLed = false;
    ExteriorYellowLed = false;
    RedGreenPosionLed = false;
    BackPositionLed = false;
    TowingBackLed = false;

    RadarOnOff = false;

    ExteriorWhiteLed3v = false;
    PRINT_P("All is OFF !");
  }
}

void MastLeds(uint8_t p)
{
  if (p != NULL) {    // As long as it existed, take it
    if (p == 4) MastLed4 = !MastLed4;
    if (p == 3) MastLed3 = !MastLed3;
    if (p == 2) MastLed2 = !MastLed2;
    if (p == 1) MastLed1 = !MastLed1;
    if (p == 0) MastLed0 = !MastLed0;
  }
  else {
    MastLed = !MastLed;
    if (MastLed)
    {
      MastLed0 = true;
      MastLed1 = true;
      MastLed2 = true;
      MastLed3 = true;
      MastLed4 = true;    
    }
    else {
      MastLed0 = false;
      MastLed1 = false;
      MastLed2 = false;
      MastLed3 = false;
      MastLed4 = false;
    }
  }
}

void InteriorLeds(uint8_t cabine, uint8_t interior)
{
  if (cabine == 0) {CabineLed = false;Serial.println("Cabine is Off");}
  if (cabine == 1) {CabineLed = true;Nv.CabineColor = CRGB::White;Serial.println("Cabine is White");}
  if (cabine == 2) {CabineLed = true;Nv.CabineColor = CRGB::Blue;Serial.println("Cabine is Blue");}
  if (cabine == 3) {CabineLed = true;Nv.CabineColor = CRGB::Red;Serial.println("Cabine is Red");}
  if (cabine != 0) 
  {
    EEPROM.put(0,Nv);
  }

  if (interior == 1)
    InteriorLed = true;
  else
    InteriorLed = false;
  PRINTF("Interior is %s !\r\n", InteriorLed?"ON":"OFF");
}

void readSettings()
{
  EEPROM.get(0,Nv);
  delay(500);
  Serial.print("\r\nLights Module ");
  Serial.print(VERSION);
  Serial.println(" Powered By Rc-Navy libraries");
  Serial.println("\r\noO Settings Oo");
  Serial.print(INPUT_MODE_STR[Nv.InputType]);
  Serial.print((Nv.InputType == 2)?" Without TTL inverter":"");
  if (Nv.XanyFilter !=0)
    PRINTF(" [ Xany ] use Channel %d(RCUL) | Filter:%d | %s\r\n",  Nv.XanyCh, Nv.XanyFilter, Xany_getPayloadName(Nv.XanyPayload));
  else
    PRINTF(" [ Xany ] use Channel %d(RCUL) | No Filter | %s\r\n",  Nv.XanyCh, Xany_getPayloadName(Nv.XanyPayload));
  PRINTF("Id      : 0x%X\r\n", Nv.Id);
  PRINTF("Cabine  : 0x%lX\r\n", Nv.CabineColor);
  PRINTF("Interior: 0x%lX\r\n", Nv.InteriorColor);

  //PRINTF("Free Memory:%d\r\n", freeMemory());

}

void writeDefaultSettings()
{
  Nv.Id = 0x99;
  Nv.Version = VERSION;
  Nv.CabineColor = CRGB::Yellow;
  Nv.InteriorColor = CRGB::Yellow;
  Nv.XanyCh  = 8;//Used Only in CPPM or SBUS mode
  Nv.InputType = INPUT_MODE_PWM;
  Nv.XanyFilter  = RC_RX_SERIAL_NO_FILTER; //No filter for FlsySky or FrSky
  Nv.XanyPayload = XANY_PAYLOAD_SW16_PLUS_PROP;//SW16 + PROP
  EEPROM.put(0,Nv);
  Serial.println("Default Value are Saved !");
}

static String usbLine;

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void processUsbConsole() {
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (!consoleMode) {
      // entrée console sur ENTER
      if (c == '\n') { enterConsoleMode(); continue; }
      // ignore tout le reste
      continue;
    }

    if (c == '\r') continue;
    if (c == '\n') {
      usbHandleCmd(usbLine);
      usbLine = "";
    } else {
      if (usbLine.length() < 120) usbLine += c;
    }
  }
}


// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void usbHandleCmd(String cmd) {
  cmd.trim();
  if (!cmd.length()) return;

  // tokenize: op + rest
  int sp = cmd.indexOf(' ');
  String op = (sp<0) ? cmd : cmd.substring(0, sp);
  String rest = (sp<0) ? ""  : cmd.substring(sp+1);
  op.toLowerCase();
  rest.trim();

  if (op == "Q" || op == "q") { exitConsoleMode(); return; }

  if (op == "H" || op == "h") { 
    usbHelp(); return; 
  }

  if (op == "SW" || op == "sw") {
    writeDefaultSettings();
    return;
  }

  if (op == "S?" || op == "s?") {
    readSettings();
    return;
  }

  if (op == "SI" || op == "si") {
    int v = rest.toInt();
    Nv.InputType = v;
    PRINTF("\r\nInput Mode is %s\r\n", INPUT_MODE_STR[Nv.InputType]);
    EEPROM.put(0,Nv);
    return;
  }

// if (op == "SX" || op == "sx") { // SX A B (A=0..1, B=0..3)
//   int sep = rest.indexOf(' ');
//   if (sep == -1) {
//     Serial.println("ERR: format SX A B");
//     return;
//   }
//   int v = rest.substring(0, sep).toInt();      // A
//   int w = rest.substring(sep + 1).toInt();     // B
//   Nv.XanyCh = v;
//   Nv.XanyPayload = w;
//   EEPROM.put(0, Nv);
//   Serial.print("OK SX -> A=");
//   Serial.print(v);
//   Serial.print(" B=");
//   Serial.println(w);
//   return;
// }
  if (op == "SX" || op == "sx") {
    int v, w;
    if (sscanf(rest.c_str(), "%d %d", &v, &w) != 2) {
      Serial.println("ERR: format SX A B");
      return;
    }
    Nv.XanyCh = v;
    Nv.XanyPayload = w;
    EEPROM.put(0, Nv);
    return;
  }

  if (op == "B" || op == "b") {
    int v = rest.toInt();
    setBrightness = v;
    PRINTF("\r\nBrightness is %d\r\n", setBrightness);
    return;
  }

  if (op == "A" || op == "a") {
    AllLeds();
    return;
  }

  if (op == "M" || op == "m") {
    int v = rest.toInt();
    MastLeds(v);
    return;
  }

  if (op == "I" || op == "i") {
    int v, w;
    if (sscanf(rest.c_str(), "%d %d", &v, &w) != 2) {
      Serial.println("ERR: format I A B");
      return;
    }
    InteriorLeds(v, w);
    return;
  }

  if (op == "L" || op == "l") {
    int v = rest.toInt();
    DefineMastLightByBoatState(v);
    return;
  }

  if (op == "L" || op == "l") {
    int v = rest.toInt();
    Radar_Speed = v;
    return;
  }

  if (op == "DN" || op == "dn") {
    DebugNibbleByNibble = !DebugNibbleByNibble;
    PRINTF("Debug Nibble by Nibble is %s !\r\n\r\n", DebugNibbleByNibble? "ON":"OFF");
    return;
  }

  if (op == "DX" || op == "dx") {
    DebugModeXany = !DebugModeXany;
    PRINTF("Debug Xany is %s !\r\n\r\n", DebugModeXany? "ON":"OFF");
    return;
  }

  if (op == "T" || op == "t") {
    AlarmCheckOnOff();
    return;
  }


  Serial.println("[USB] Unknown. Type 'H or h'.");
}

static void enterConsoleMode() {
  consoleMode = true;
  setBrightness = 255;
  AlarmCheckOnOff();//Stop failsafe check (equal T command)
  PRINT_P("Console mode is Ready (H Help)\r\n");
}

static void exitConsoleMode() {
  consoleMode = false;
  setBrightness = 50;
  AlarmCheckOnOff();
  PRINT_P("Quit console mode\r\n");
}



